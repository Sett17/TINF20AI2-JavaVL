package recyclingYard3;

public interface Recycable {
    public void recycle();
}
