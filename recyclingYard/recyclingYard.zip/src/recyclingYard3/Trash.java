package recyclingYard3;

public class Trash{
    public double getWeight() {
        return weight;
    }

    protected void setWeight(double weight) {
        this.weight = weight;
    }

    private double weight;

    public Trash(double weight) {
        this.weight = weight;
//        System.out.println("starting weight: " + weight);
    }
}
